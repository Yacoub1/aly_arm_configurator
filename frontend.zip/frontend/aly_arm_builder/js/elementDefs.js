/**
 * elementDefs.js
 *
 * Catalogue of all draggable palette items.
 * Each entry defines how a segment renders in the TF chain and how its
 * joint/link XML is generated.
 *
 * Base chain (world → base_link → motor_holder_link) is hardcoded in
 * xacroGenerator.js — do NOT add motor_holder_link here.
 *
 * Chain pattern per DOF:
 *   motor_holder_link
 *     └─[fixed]─ motor_assembly  (link_motor_N)
 *          └─[revolute|prismatic]─ active_hirth  (link_active_N)
 *               └─[fixed]─ passive_hirth (link_passive_N)
 *                    └─ next module ...
 */

const ELEMENT_DEFS = {

  // ── DOF Modules ─────────────────────────────────────────────────────────────
  joint_revolute: {
    label: 'Revolute Joint Module',
    color: '#ff6b35',
    subLinks: [
      { role: 'motor_assembly', mesh: 'motor_assembly.dae',                            jointAfter: 'fixed' },
      { role: 'active',         mesh: 'lnk_active_0deg_hirth_18d0_V2_a2plus-Part.dae', jointAfter: 'revolute', jointAxis: '0 0 1' },
    ],
    defaults: { phi: 0.0, lower: -1.25, upper: 1.20, effort: 10.0, velocity: 1.0, jointType: 'revolute' },
  },

  joint_prismatic: {
    label: 'Prismatic Joint Module',
    color: '#ffd700',
    subLinks: [
      { role: 'motor_assembly', mesh: 'motor_assembly_presmatic_joint.dae',             jointAfter: 'fixed' },
      { role: 'active',         mesh: 'lnk_active_0deg_hirth_18d0_V2_a2plus-Part.dae', jointAfter: 'prismatic', jointAxis: '0 0 1' },
    ],
    defaults: { phi: 0.0, lower: 0.0, upper: 0.045, effort: 10.0, velocity: 1.0, jointType: 'prismatic' },
  },

  // ── Connectors ───────────────────────────────────────────────────────────────
  passive_link: {
    label: 'Passive Hirth Link',
    color: '#00e5ff',
    subLinks: [
      { role: 'passive', mesh: 'lnk_passive_0deg_hirth_18_V3-Body.dae', jointAfter: 'fixed', offsetX: 0.036 },
    ],
    defaults: { phi: 1.570 },
  },

  active_link: {
    label: 'Active Hirth Link',
    color: '#ff9955',
    subLinks: [
      { role: 'active', mesh: 'lnk_active_0deg_hirth_18d0_V2_a2plus-Part.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0 },
  },

  // ── Motor Holders ────────────────────────────────────────────────────────────
  motor_holder_90_77: {
    label: 'Motor Holder 90° (77mm)',
    color: '#44ff88',
    subLinks: [
      { role: 'motor_holder', mesh: 'base_motorholder_90deg_V4-Body.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0, height: 0.0804 },
  },

  motor_holder_90_56: {
    label: 'Motor Holder 90° (56mm)',
    color: '#44ff88',
    subLinks: [
      { role: 'motor_holder', mesh: 'base_motorholder_90deg_V4-Body.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0, height: 0.060 },
  },

  motor_holder_0: {
    label: 'Motor Holder 0° (inline)',
    color: '#88ff44',
    subLinks: [
      { role: 'motor_holder', mesh: 'base_motorholder_90deg_V4-Body.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0, height: 0.0804 },
  },

  // ── End Effectors ────────────────────────────────────────────────────────────
  rack_pen: {
    label: 'Rack + Pen Holder',
    color: '#bb88ff',
    subLinks: [
      { role: 'rack',       mesh: 'rack_assebmly-Part.dae',  jointAfter: 'prismatic', jointAxis: '0 0 1' },
      { role: 'pen_holder', mesh: 'pen_holder_assembly.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0, lower: 0.0, upper: 0.045, effort: 10.0, velocity: 1.0, jointType: 'prismatic' },
  },

  tool_flange: {
    label: 'Tool Flange',
    color: '#ff88bb',
    subLinks: [
      { role: 'tool_flange', mesh: 'tool_flange.dae', jointAfter: 'fixed' },
    ],
    defaults: { phi: 0.0 },
  },
};
