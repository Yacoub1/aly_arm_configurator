/**
 * xacroGenerator.js
 *
 * Builds a valid xacro/URDF string from the current chain state.
 *
 * Rules:
 *  - joint + child link are INTERLEAVED (not batched) — valid URDF requires
 *    each link to appear after the joint that references it as a child.
 *  - The base chain (world → base_link → motor_holder_link) is hardcoded here.
 *    Nothing in ELEMENT_DEFS should re-emit motor_holder_link.
 *  - Joint type per subLink is taken from sl.jointAfter; props.jointType
 *    overrides only when sl.jointAfter is already non-fixed (i.e. the DOF link).
 */

function buildXacro() {
  const j0x = parseFloat(document.getElementById('j0_x_input').value) || 0.003;
  const f   = v => parseFloat(v).toFixed(4);

  // ── Collect phi xacro:property lines ──────────────────────────────────────
  const propLines = [];
  chain.forEach((seg, idx) => {
    if (seg.props.phi !== undefined)
      propLines.push(`  <xacro:property name="phi_${idx + 1}" value="${f(seg.props.phi)}" />`);
  });

  // ── Build interleaved joint+link body ─────────────────────────────────────
  let body       = '';
  let parentLink = 'motor_holder_link';
  let cfgIdx     = 0;   // fixed joint counter
  let dofIdx     = 0;   // DOF joint counter

  chain.forEach((seg, segIdx) => {
    const def    = ELEMENT_DEFS[seg.type];
    const p      = seg.props;
    const phiKey = `phi_${segIdx + 1}`;
    let linkIdx = 0;
    def.subLinks.forEach(sl => {
      // ── Resolve joint type ───────────────────────────────────────────────
      const slJtype = sl.jointAfter || 'fixed';
      const jtype   = (slJtype !== 'fixed' && p.jointType) ? p.jointType : slJtype;
      const isDOF   = jtype !== 'fixed';

      const jointName = isDOF ? `joint_${dofIdx}` : `config_joint_${cfgIdx}`;
      const baseName = resolveRoleName(sl.role, segIdx);
      const childName = `${baseName}_${linkIdx++}`;

      // ── Origin ───────────────────────────────────────────────────────────
      let originStr;
      switch (sl.role) {
        case 'motor_holder':
          originStr = `<origin xyz="0 0 ${f(p.height || 0.0804)}" rpy="0 \${${phiKey}} 0"/>`;
          break;
        case 'motor_assembly':
          originStr = `<origin xyz="0 0 0" rpy="0 \${${phiKey}} 0"/>`;
          break;
        case 'passive':
          originStr = `<origin xyz="${f(sl.offsetX || 0.036)} 0 0" rpy="\${${phiKey}} 0 0"/>`;
          break;
        case 'active':
          originStr = `<origin xyz="0.036 0 0" rpy="0 \${${phiKey}} 0"/>`;
          break;
        case 'rack':
          originStr = `<origin xyz="0.045 -0.030 0.0" rpy="3.14 -1.57 0"/>`;
          break;
        case 'pen_holder':
          originStr = `<origin xyz="0 0.020 0.022" rpy="0 0 \${${phiKey}}"/>`;
          break;
        default:
          originStr = `<origin xyz="0 0 0" rpy="0 0 \${${phiKey}}"/>`;
      }

      // ── Axis + limit (DOF joints only) ───────────────────────────────────
      const axisLimit = isDOF ? `
    <axis xyz="${sl.jointAxis || '0 0 1'}"/>
    <limit effort="${f(p.effort ?? 10)}" lower="${f(p.lower ?? -1.25)}" upper="${f(p.upper ?? 1.20)}" velocity="${f(p.velocity ?? 1.0)}"/>` : '';

      // ── Visual RPY ───────────────────────────────────────────────────────
      const visRpy = sl.role === 'passive'         ? '0 1.57 0'
                   : sl.role === 'motor_assembly'  ? '1.57 0 0'
                   : '0 0 0';

      // ── Emit joint → link (interleaved) ─────────────────────────────────
      body += `
  <joint name="${jointName}" type="${jtype}">
    <parent link="${parentLink}"/>
    <child link="${childName}"/>
    ${originStr}${axisLimit}
  </joint>

  <link name="${childName}">
    <visual>
      <origin xyz="0 0 0" rpy="${visRpy}"/>
      <geometry><mesh filename="http://localhost:8000/meshes/${sl.mesh}" scale="1 1 1"/></geometry>
    </visual>
    <collision>
      <origin xyz="0 0 0" rpy="${visRpy}"/>
      <geometry><mesh filename="http://localhost:8000/meshes/${sl.mesh}" scale="1 1 1"/></geometry>
    </collision>
  </link>
`;
      if (isDOF) dofIdx++; else cfgIdx++;
      parentLink = childName;
    });
  });

  // ── Assemble full xacro ───────────────────────────────────────────────────
  const propsBlock = propLines.length
    ? `\n  <!-- Configuration offset angles -->\n${propLines.join('\n')}\n`
    : '';

  return `<?xml version="1.0"?>
<robot xmlns:xacro="http://www.ros.org/wiki/xacro" name="aly_arm">

  <!-- Base offset -->
  <xacro:property name="j0_x" value="${f(j0x)}" />${propsBlock}
  <link name="world"/>

  <joint name="world_joint" type="fixed">
    <parent link="world"/>
    <child link="base_link"/>
    <origin xyz="0 0 0" rpy="0 0 0"/>
  </joint>

  <link name="base_link">
    <visual><geometry>
      <mesh filename="http://localhost:8000/meshes/base_fixture-Body.dae" scale="1 1 1"/>
    </geometry></visual>
    <collision><geometry>
      <mesh filename="http://localhost:8000/meshes/base_fixture-Body.dae" scale="1 1 1"/>
    </geometry></collision>
  </link>

  <joint name="base_holder_joint" type="fixed">
    <parent link="base_link"/>
    <child link="motor_holder_link"/>
    <origin xyz="\${j0_x} 0 0" rpy="0 0 0"/>
  </joint>

  <link name="motor_holder_link">
    <visual><geometry>
      <mesh filename="http://localhost:8000/meshes/base_motorholder_90deg_V4-Body.dae" scale="1 1 1"/>
    </geometry></visual>
    <collision><geometry>
      <mesh filename="http://localhost:8000/meshes/base_motorholder_90deg_V4-Body.dae" scale="1 1 1"/>
    </geometry></collision>
  </link>
${body}
</robot>`;
}

// ── Syntax highlighting for the preview modal ─────────────────────────────────
function syntaxHighlight(xml) {
  return xml
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/(&lt;\/?[\w:]+)/g,  '<span class="xml-tag">$1</span>')
    .replace(/(\s[\w:]+)=/g,      '<span class="xml-attr">$1</span>=')
    .replace(/="([^"]*)"/g,       '="<span class="xml-value">$1</span>"')
    .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="xml-comment">$1</span>');
}
