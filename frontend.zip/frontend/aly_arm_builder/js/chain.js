/**
 * chain.js
 *
 * Owns the live chain array and all add / remove / reorder operations.
 * Pure data — no DOM manipulation (that lives in renderer.js).
 */

let chain      = [];   // array of segment objects { id, type, label, color, props }
let selectedId = null;
let nextId     = 1;

// ── Helpers ───────────────────────────────────────────────────────────────────
function getSegment(id)    { return chain.find(s => s.id === id) ?? null; }
function getChainCopy()    { return chain.map(s => ({ ...s, props: { ...s.props } })); }

// ── Mutations ─────────────────────────────────────────────────────────────────
function addSegment(type, insertIdx) {
  const def = ELEMENT_DEFS[type];
  if (!def) return null;
  const seg = {
    id:    nextId++,
    type,
    label: def.label,
    color: def.color,
    props: { ...def.defaults },
  };
  chain.splice(insertIdx, 0, seg);
  return seg;
}

function removeSegment(id) {
  const idx = chain.findIndex(s => s.id === id);
  if (idx === -1) return false;
  chain.splice(idx, 1);
  if (selectedId === id) selectedId = null;
  return true;
}

function reorderSegment(id, toIdx) {
  const fromIdx = chain.findIndex(s => s.id === id);
  if (fromIdx === -1) return;
  const [seg] = chain.splice(fromIdx, 1);
  const adjusted = toIdx > fromIdx ? toIdx - 1 : toIdx;
  chain.splice(adjusted, 0, seg);
}

function clearChain() {
  chain      = [];
  selectedId = null;
}

function applySegmentProps(id, newProps) {
  const seg = getSegment(id);
  if (!seg) return;
  Object.assign(seg.props, newProps);
}

// ── Default / example chain matching aly_arm.xacro ───────────────────────────
function loadExampleChain() {
  const initial = [
    { type: 'joint_revolute', props: { phi: 0.0,   lower: -1.25, upper: 1.20,  effort: 10, velocity: 1.0, jointType: 'revolute'  } },
    { type: 'passive_link',   props: { phi: 1.570 } },
    { type: 'joint_revolute', props: { phi: 0.0,   lower: -1.25, upper: 1.20,  effort: 10, velocity: 1.0, jointType: 'revolute'  } },
    { type: 'passive_link',   props: { phi: 1.570 } },
    { type: 'joint_revolute', props: { phi: 0.0,   lower: -1.25, upper: 1.20,  effort: 10, velocity: 1.0, jointType: 'revolute'  } },
    { type: 'passive_link',   props: { phi: 1.570 } },
    { type: 'rack_pen',       props: { phi: 1.570, lower: 0.0,   upper: 0.045, effort: 10, velocity: 1.0, jointType: 'prismatic' } },
  ];
  initial.forEach(s => addSegment(s.type, chain.length) && Object.assign(chain[chain.length - 1].props, s.props));
}

// ── Link name resolution (shared by renderer + generator) ────────────────────
function resolveRoleName(role, segIdx) {
  const map = {
    active:        `link_active_${segIdx}`,
    passive:       `link_passive_${segIdx}`,
    motor_holder:  `motor_holder_link_${segIdx}`,
    motor_assembly:`link_motor_${segIdx}`,
    rack:          `rack_link`,
    pen_holder:    `pen_holder_link`,
    tool_flange:   `tool_flange_link`,
  };
  return map[role] ?? `link_${role}_${segIdx}`;
}
